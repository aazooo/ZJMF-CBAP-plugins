<?php
return ["url" => ["title" => "接口地址", "type" => "text", "value" => "", "tip" => ""], "user" => ["title" => "keyID", "type" => "text", "value" => "", "tip" => ""], "pass" => ["title" => "keySecret", "type" => "text", "value" => "", "tip" => ""], "sign" => ["title" => "SignName签名    例如：【签名】", "type" => "text", "value" => "", "tip" => "请填写带有“【】”的，例如：【签名】"]];

?>