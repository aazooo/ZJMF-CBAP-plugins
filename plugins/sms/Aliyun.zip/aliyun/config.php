<?php
return ["AccessKeyId" => ["title" => "AccessKey ID", "type" => "text", "value" => "", "tip" => ""], "AccessKeySecret" => ["title" => "AccessKey Secret", "type" => "text", "value" => "", "tip" => ""], "SignName" => ["title" => "短信签名", "type" => "text", "value" => "", "tip" => ""]];

?>