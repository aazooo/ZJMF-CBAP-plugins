<?php
return ["username" => ["title" => "用户名", "type" => "text", "value" => "", "tip" => "平台用户名"], "key" => ["title" => "用户Secret Key", "type" => "text", "value" => "", "tip" => "平台获取接口信息"], "sign" => ["title" => "短信签名", "type" => "text", "value" => "", "tip" => "已经通过审核的签名"], "channel" => ["title" => "发信通道", "type" => "text", "value" => "", "tip" => "发信通道ID"]];

?>