<?php
return ["app_code" => ["title" => "appCode", "type" => "text", "value" => "", "tip" => ""]];

?>