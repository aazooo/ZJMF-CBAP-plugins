<?php
return ["url" => "https://idcert.market.alicloudapi.com", "path" => "/idcard"];

?>