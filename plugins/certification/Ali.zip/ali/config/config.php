<?php
return ["api_version" => "1.0", "post_charset" => "UTF-8", "format" => "json", "charset" => "UTF-8", "gateway_url" => "https://openapi.alipay.com/gateway.do", "return_url" => "/login.php", "sign_type" => "RSA2", "biz_code" => "SMART_FACE", "debug" => false];

?>