<?php
return ["fuplusx_url" => "https://fephone.market.alicloudapi.com", "app_code" => ""];

?>