<?php
return ["module_name" => ["title" => "显示名称", "type" => "text", "value" => "涪擎实名认证（高级版）", "tip" => "前台显示的名称"], "app_code" => ["title" => "appCode", "type" => "text", "value" => "", "tip" => "请输入app_code"], "type" => ["title" => "认证方式", "type" => "select", "options" => ["2" => "两要素（验证姓名+身份证号）", "3" => "银行三要素（验证姓名+身份证号+银行卡号）", "4" => "手机三要素（验证姓名+身份证号+手机号）", "5" => "银行四要素（验证姓名+身份证号+银行卡号+手机号）"], "value" => "2", "tip" => "认证方式"]];

?>