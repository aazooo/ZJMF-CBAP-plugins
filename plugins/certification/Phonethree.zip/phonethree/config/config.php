<?php
return ["phonethree_url" => "https://phone3.market.alicloudapi.com/phonethree", "app_code" => ""];

?>