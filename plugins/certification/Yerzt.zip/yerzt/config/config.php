<?php
return ["number" => "11", "version" => "1.3", "auth_id" => "", "auth_key" => "", "teamName" => "云外科技", "author" => "云外", "programName" => "Zkeys支付宝人脸认证模块", "qq" => "37893492", "url" => "http://open.cloudwai.com/", "release_time" => "2021-03-04 01:21:54"];

?>