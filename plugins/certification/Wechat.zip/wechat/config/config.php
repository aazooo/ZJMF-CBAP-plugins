<?php
return ["return_url" => "/login.php", "biz_code" => "FACE", "debug" => false];

?>