<?php
return ["RuleId" => ["title" => "业务流程ID", "type" => "text", "value" => "", "tip" => ""], "SecretId" => ["title" => "SecretId", "type" => "text", "value" => "", "tip" => ""], "SecretKey" => ["title" => "SecretKey", "type" => "text", "value" => "", "tip" => ""]];

?>