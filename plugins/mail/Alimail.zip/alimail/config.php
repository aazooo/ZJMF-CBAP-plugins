<?php
return ["accessKeyId" => ["title" => "accessKeyId", "type" => "text", "value" => "", "tip" => ""], "accessKeySecret" => ["title" => "accessKeySecret", "type" => "text", "value" => "", "tip" => ""], "accountName" => ["title" => "发信地址", "type" => "text", "value" => "", "tip" => ""], "fromAlias" => ["title" => "发信人昵称", "type" => "text", "value" => "", "tip" => ""]];

?>