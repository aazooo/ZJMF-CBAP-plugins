const plugin_lang = {
  /* 商品限購 */
  single_product_text1: "商品關聯限購/續費",
  single_product_text2:
    "配置商品是否需要某商品才可以購買/續費，或需要與某項商品共同購買/續費",
  single_product_text3: "新增",
  single_product_text4: "被限製商品",
  single_product_text5: "限製商品",
  single_product_text6: "限制類型",
  single_product_text7: "狀態",
  single_product_text8: "操作",
  single_product_text9: "捆綁",
  single_product_text10: "必需",
  single_product_text11: "互斥",
  single_product_text12: "必填",
  single_product_text13: "確認刪除該商品關聯?",
  single_product_text14: "確定",
  single_product_text15: "取消",
  single_product_text16: "編輯",
  single_product_text17: "新增",
  single_product_text18: "保存",
  single_product_text19:
    "捆綁：選擇的商品須同時購買或續費（退款時也會同步退款）",
  single_product_text20: "必需：購買或續費被限製商品時，帳戶中需",
  single_product_text21: "擁有",
  single_product_text22: "啟動中的限製商品",
  single_product_text23: "互斥：購買或續費被限製商品時，帳戶中需",
  single_product_text24: "沒有",
  single_product_text25: "啟動中的限製商品",
  single_product_text26:
    "商品被限制後，仍能單獨被上下游代理，建議依業務需求配置可被代理商品",
};

window.plugin_lang = plugin_lang;
