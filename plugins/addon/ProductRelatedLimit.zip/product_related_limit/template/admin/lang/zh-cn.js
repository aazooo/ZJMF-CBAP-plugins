const plugin_lang = {
  /* 商品限购 */
  single_product_text1: "商品关联限购/续费",
  single_product_text2:
    "配置商品是否需要某个商品才可以购买/续费，或需要与某个商品共同购买/续费",
  single_product_text3: "新增",
  single_product_text4: "被限制商品",
  single_product_text5: "限制商品",
  single_product_text6: "限制类型",
  single_product_text7: "状态",
  single_product_text8: "操作",
  single_product_text9: "捆绑",
  single_product_text10: "必需",
  single_product_text11: "互斥",
  single_product_text12: "必填",
  single_product_text13: "确认删除该商品关联?",
  single_product_text14: "确定",
  single_product_text15: "取消",
  single_product_text16: "编辑",
  single_product_text17: "新增",
  single_product_text18: "保存",
  single_product_text19:
    "捆绑：选择的商品须同时购买或续费（退款时也会同步退款）",
  single_product_text20: "必需：购买或续费被限制商品时，账户中需",
  single_product_text21: "拥有",
  single_product_text22: "激活中的限制商品",
  single_product_text23: "互斥：购买或续费被限制商品时，账户中需",
  single_product_text24: "没有",
  single_product_text25: "激活中的限制商品",
  single_product_text26:
    "商品被限制后，仍能单独被上下游代理，建议根据业务需求配置可被代理商品",
};

window.plugin_lang = plugin_lang;
