const plugin_lang = {
  /* Product purchase limit */
  single_product_text1: "Product related purchase limit/renewal",
  single_product_text2:
    "Configure whether the product requires a certain product before it can be purchased/renewed, or needs to be purchased/renewed together with a certain product",
  single_product_text3: "New",
  single_product_text4: "Restricted product",
  single_product_text5: "Restricted Products",
  single_product_text6: "Restriction type",
  single_product_text7: "Status",
  single_product_text8: "Operation",
  single_product_text9: "Bundle",
  single_product_text10: "Required",
  single_product_text11: "Mutually exclusive",
  single_product_text12: "Required",
  single_product_text13: "Confirm to delete this product association?",
  single_product_text14: "OK",
  single_product_text15: "Cancel",
  single_product_text16: "Edit",
  single_product_text17: "New",
  single_product_text18: "Save",
  single_product_text19:
    "Bundling: The selected products must be purchased or renewed at the same time (refunds will also be refunded simultaneously)",
  single_product_text20:
    "Required: required in the account when purchasing or renewing restricted products",
  single_product_text21: "Own",
  single_product_text22: "Restricted products under activation",
  single_product_text23:
    "Mutually exclusive: When purchasing or renewing restricted products, the account is required",
  single_product_text24: "No",
  single_product_text25: "Restricted products under activation",
  single_product_text26:
    "After a product is restricted, it can still be independently agented by upstream and downstream agents. It is recommended to configure agents that can be agented according to business needs.",
};

window.plugin_lang = plugin_lang;
