const plugin_lang = {
  /* User level */
  new_create: "New",
  update: "Modify",
  delete: "delete",
  sure: "Sure",
  cancel: "Cancel",
  sureDelete: "Confirm to delete?",
  clinet_level: "User level",
  basic_info: "Basic information",
  representative_color: "Representative color",
  customer: "Customer",
  notes: "Notes",
  edit: "Edit",
  hold: "Save",
  order_new: "Add",
  product_preference: "Product preference",
  discount_ratio: "Discount ratio",
  levevl_tip: "5% off, 95% off when the user buys",
  baidu_price_num: "Baidu_price_NUM",
  baidu_total: "Total discount",
  order_index: "Serial number",
  operation: "Operation",
  input: "Please enter",
  select: "Please select",
  tailorism: "Product",
  verify2: "The number between, up to two decimals",
  level_text1:
    "The member center displays the user level to which the user belongs",
};

window.plugin_lang = plugin_lang;
