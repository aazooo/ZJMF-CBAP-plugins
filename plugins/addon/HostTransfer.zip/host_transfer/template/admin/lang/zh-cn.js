const plugin_lang = {
  /* 产品转移插件 */
  host_transfer_text1: "产品转移插件",
  host_transfer_text2: "此处展示产品转移记录,如需转移产品，请前往用户详情-产品信息页执行产品转移操作",
  host_transfer_text3: "请输入关键字",
  host_transfer_text4: "产品ID",
  host_transfer_text5: "商品名称",
  host_transfer_text6: "商品标识",
  host_transfer_text7: "原始用户",
  host_transfer_text8: "目标用户",
  host_transfer_text9: "迁移时间",
  host_transfer_text10: "操作人",
  host_transfer_text11: "产品转移",
  host_transfer_text12: "确认转移",
  host_transfer_text13: "转移目标用户:",
  host_transfer_text14: "转移产品信息:",
  host_transfer_text15: "备注",
  host_transfer_text16: "请注意：该产品已关联其他商品，迁移将自动将所有关联的产品一起迁移",
  host_transfer_text17: "关联产品信息:",
  host_transfer_text18: "产品迁移不会迁移订单信息",
  host_transfer_text19: "若存在VPC/安全组/付费系统镜像,将同步到目标用户",
  host_transfer_text20: "查询",
};

window.plugin_lang = plugin_lang;
