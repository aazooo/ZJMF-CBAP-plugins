const plugin_lang = {
  /* 產品轉移插件 */
  host_transfer_text1: "產品轉移插件",
  host_transfer_text2: "此處展示產品轉移記錄,如需轉移產品，請前往用戶詳情-產品信息頁執行產品轉移操作",
  host_transfer_text3: "請輸入關鍵字",
  host_transfer_text4: "產品ID",
  host_transfer_text5: "商品名稱",
  host_transfer_text6: "商品標識",
  host_transfer_text7: "原始用戶",
  host_transfer_text8: "目標用戶",
  host_transfer_text9: "遷移時間",
  host_transfer_text10: "操作人",
  host_transfer_text11: "產品轉移",
  host_transfer_text12: "確認轉移",
  host_transfer_text13: "轉移目標用戶:",
  host_transfer_text14: "轉移產品信息:",
  host_transfer_text15: "備註",
  host_transfer_text16: "請註意：該產品已關聯其他商品，遷移將自動將所有關聯的產品壹起遷移",
  host_transfer_text17: "關聯產品信息:",
  host_transfer_text18: "產品遷移不會遷移訂單信息",
  host_transfer_text19: "若存在VPC/安全組/付費系統鏡像,將同步到目標用戶",
  host_transfer_text20: "查詢",
};

window.plugin_lang = plugin_lang;
