const plugin_lang = {
  /* Product transfer plugin */
  host_transfer_text1: "Product transfer plug-in",
  host_transfer_text2: "Product transfer records are displayed here, if you need to transfer products, please go to the User details - Product information page to perform product transfer operation",
  host_transfer_text3: "Please enter keywords",
  host_transfer_text4: "Product ID",
  host_transfer_text5: "Product name",
  host_transfer_text6: "Product identification",
  host_transfer_text7: "original user",
  host_transfer_text8: "Target user",
  host_transfer_text9: "Migration time",
  host_transfer_text10: "Operator",
  host_transfer_text11: "Product transfer",
  host_transfer_text12: "Confirm transfer",
  host_transfer_text13: "Transfer target user :",
  host_transfer_text14: "Transfer product information :",
  host_transfer_text15: "Note",
  host_transfer_text16: "Please note: This product has been associated with other products, the migration will automatically migrate all the associated products together",
  host_transfer_text17: "Associated Product Information :",
  host_transfer_text18: "Product migration does not migrate order information",
  host_transfer_text19: "If there is a VPC/ security group/paid system image, synchronize it to the target user",
  host_transfer_text20: "Query",
};

window.plugin_lang = plugin_lang;
