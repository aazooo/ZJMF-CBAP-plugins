const plugin_lang = {
  /* Statistics */
  year_income: "Annual Income Statistics ",
  expect_income: "Expected income statistics ",
  product_income: "Product Income Statistics ",
  month_income: "Monthly income statistics ",
  month_order_income: "Annual Order Statistics ",
  income_tip: "Annual Income Report ",
  year: "Year ",
  balance: "net income ",
  expect_total_income: "estimated total income ",
  month: "Month ",
  statistics: "Statistics",
  subtotal: "Subtotal",
  tip10: "No data found ",
  total_income: "Total income",
  client_care_label44: "Date",
  amount_in: "Income ",
  amount_out: "Expenses ",
  statistics_month: "month ",
  new: "New order ",
  new_signup_user: "New registered user ",
  renew_order: "Renewal Order ",
  upgrade: "Upgrade order ",
  renew: "Renew ",
  refund: "refund",
  product_name: "Product name ",
  units_sold: "Units sold",
  income_tip1:
    "This report also presents data for the last 3 years, breaking down income by month.",
  income_tip2: "Income Report ",
  income_tip3: "This report shows the daily income for the current month ",
  income_tip4:
    "The report shows the total number of new customer registrations, new orders, renewal orders, promotion and demotion orders, and compares each item to the previous year on a chart.",
  income_tip5: "Product Revenue ",
  income_tip6:
    "This report shows the revenue of all items in the current month by item group ",
  income_tip7:
    "The report shows the projected revenue per month for the next three years if all activated products are renewed within the corresponding cycle ",
};

window.plugin_lang = plugin_lang;
