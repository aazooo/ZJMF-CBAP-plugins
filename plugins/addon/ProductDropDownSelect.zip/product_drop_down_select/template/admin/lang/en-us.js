const plugin_lang = {
  /* Product drop-down optimization - */
  product_select: "Product drop-down Optimization",
  product_select_tip: "Please select a drop-down style for the item drop-down box on the product info details page in the system",
  product_examples: "Examples",
  product_id_empty_tip: "Please select an item",
  product_hold: "Save",
  product_first_group: "Level 1 group",
  product_second_group: "Secondary Group"
};

window.plugin_lang = plugin_lang;
