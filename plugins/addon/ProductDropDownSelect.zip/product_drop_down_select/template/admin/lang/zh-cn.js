const plugin_lang = {
  /* 商品下拉优化- */
  product_select: "商品下拉优化",
  product_select_tip: "请选择系统中产品信息详情页的商品下拉框的下拉样式",
  product_examples: "示例",
  product_id_empty_tip: "请选择商品",
  product_hold: "保存",
  product_first_group: "一级分组",
  product_second_group: "二级分组"
};

window.plugin_lang = plugin_lang;
