const plugin_lang = {
  /* 商品下拉優化- */
  product_select: "商品下拉優化",
  product_select_tip: "請選擇系統中產品信息詳情頁的商品下拉框的下拉樣式",
  product_examples: "示例",
  product_id_empty_tip: "請選擇商品",
  product_hold: "保存",
  product_first_group: "壹級分組",
  product_second_group: "二級分組"
};

window.plugin_lang = plugin_lang;
