const plugin_lang = {
  /* Email Administrator */
  email_notice_admin: "Email notification administrator ",
  email_notice_tip: "Set the email notifications that administrators need to receive here ",
  notify_personnel: "Notification personnel ",
  hold: "Save ",
  select: "Please select",
  action_name: "Action name ",
  email_interface: "Mail interface ",
  sms_template: "SMS template",
  email_temp: "Mail Template ",
  isOpen: "Enabled or not ",
};

window.plugin_lang = plugin_lang;
