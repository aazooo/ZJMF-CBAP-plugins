const plugin_lang = {
  /* 邮件通知管理员 */
  email_notice_admin: "邮件通知管理员",
  email_notice_tip: "在此处设定管理员需要接收的邮件通知",
  notify_personnel: "通知人员",
  hold: "保存",
  select: "请选择",
  action_name: "动作名称",
  email_interface: "邮件接口",
  sms_template: "短信模板",
  email_temp: "邮件模板",
  isOpen: "是否启用",
};

window.plugin_lang = plugin_lang;
