const plugin_lang = {
  /* 郵件通知管理員 */
  email_notice_admin: "郵件通知管理員",
  email_notice_tip: "在此處設定管理員需要接收的郵件通知",
  notify_personnel: "通知人員",
  hold: "保存",
  select: "請選擇",
  action_name: "動作名稱",
  email_interface: "郵件接口",
  sms_template: "短信模板",
  email_temp: "郵件模板",
  isOpen: "是否啟用",
};

window.plugin_lang = plugin_lang;
