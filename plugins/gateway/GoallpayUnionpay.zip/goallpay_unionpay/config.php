<?php
return ["module_name" => ["title" => "名称", "type" => "text", "value" => "GoallpayUnionpay", "tip" => "friendly name", "size" => 200], "merchant_id" => ["title" => "Merchant ID", "type" => "text", "value" => "", "tip" => "商户 ID，由 GoAllPay 分配", "size" => 200], "key" => ["title" => "密钥", "type" => "text", "value" => "", "tip" => "签名密钥 Key（接入 GoAllPay 时分配）", "size" => 200], "currency" => ["title" => "支持货币单位", "type" => "text", "value" => "", "tip" => ""]];

?>