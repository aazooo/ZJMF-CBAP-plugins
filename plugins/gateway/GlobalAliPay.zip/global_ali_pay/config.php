<?php
return ["module_name" => ["title" => "名称", "type" => "text", "value" => "支付宝国际支付(新)", "tip" => ""], "partner" => ["title" => "支付宝用户ID", "type" => "text", "value" => "", "tip" => "境外收单香港产品商户在支付宝的用户ID,2088开头的16位数字"], "key" => ["title" => "md5密钥", "type" => "text", "value" => "", "tip" => ""], "currency" => ["title" => "支持货币单位", "type" => "text", "value" => "", "tip" => ""], "rate" => ["title" => "汇率", "type" => "text", "value" => "", "tip" => "支持货币单位/系统货币"]];

?>