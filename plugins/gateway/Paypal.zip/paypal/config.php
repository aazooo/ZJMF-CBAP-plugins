<?php
return ["module_name" => ["title" => "名称", "type" => "text", "value" => "Paypal", "tip" => "友好的显示名称"], "clientId" => ["title" => "clientId", "type" => "text", "value" => "", "tip" => ""], "clientSecret" => ["title" => "clientSecret", "type" => "text", "value" => "", "tip" => ""]];

?>