<?php
$domain = configuration("website_url");
return [];

?>