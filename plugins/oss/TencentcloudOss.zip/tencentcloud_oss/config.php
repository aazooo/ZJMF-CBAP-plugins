<?php
return ["module_name" => ["title" => "名称", "type" => "text", "value" => "腾讯云对象存储", "tip" => "友好的显示名称"], "secret_id" => ["title" => "Secret ID", "type" => "text", "value" => "", "tip" => "Client ID"], "secert_key" => ["title" => "Secret Key", "type" => "text", "value" => "", "tip" => "Secret Key"], "bucket" => ["title" => "Bucket", "type" => "text", "value" => "", "tip" => "存储桶名称"], "region" => ["title" => "Region", "type" => "text", "value" => "", "tip" => "Bucket 所在区域"]];

?>