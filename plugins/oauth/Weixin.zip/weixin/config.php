<?php
return ["appid" => ["title" => "appid", "type" => "text", "value" => "", "tip" => "appid"], "appSecret" => ["title" => "appSecret", "type" => "text", "value" => "", "tip" => "appSecret"]];

?>