<?php
return ["client_id" => ["title" => "Client ID", "type" => "text", "value" => "", "tip" => "Client ID (原 AppKey 和 SuiteKey)"], "client_secret" => ["title" => "Client Secret", "type" => "text", "value" => "", "tip" => "Client Secret (原 AppSecret 和 SuiteSecret)"]];

?>