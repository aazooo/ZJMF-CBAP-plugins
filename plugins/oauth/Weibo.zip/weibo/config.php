<?php
return ["app_key" => ["title" => "App Key", "type" => "text", "value" => "", "tip" => "App Key"], "app_secret" => ["title" => "App Secret", "type" => "text", "value" => "", "tip" => "App Secret"]];

?>