<?php
return ["corp_id" => ["title" => "CorpID", "type" => "text", "value" => "", "tip" => "CorpID"], "suite_id" => ["title" => "SuiteID", "type" => "text", "value" => "", "tip" => "SuiteID"], "secret" => ["title" => "Secret", "type" => "text", "value" => "", "tip" => "Secret"], "token" => ["title" => "Token", "type" => "text", "value" => "", "tip" => "Token"], "aes_key" => ["title" => "EncodingAESKey", "type" => "text", "value" => "", "tip" => "EncodingAESKey"]];

?>