<?php
return ["app_id" => ["title" => "APP ID", "type" => "text", "value" => "", "tip" => "APP ID"], "app_secret" => ["title" => "APP Key", "type" => "text", "value" => "", "tip" => "APP Key"]];

?>