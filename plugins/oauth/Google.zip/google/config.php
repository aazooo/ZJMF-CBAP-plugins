<?php
return ["client_id" => ["title" => "Client ID", "type" => "text", "value" => "", "tip" => "Client ID"], "client_secret" => ["title" => "Client secret", "type" => "text", "value" => "", "tip" => "Client secret"]];

?>