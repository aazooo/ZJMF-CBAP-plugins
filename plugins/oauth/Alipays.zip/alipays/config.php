<?php
return ["app_id" => ["type" => "text", "title" => "应用ID", "value" => "", "tip" => "查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应的APPID。创建应用后生成，分配给应用的appid"], "app_private_key" => ["type" => "textarea", "title" => "应用私钥", "value" => "", "tip" => ""], "alipay_public_key" => ["type" => "textarea", "title" => "支付宝公钥", "value" => "", "tip" => ""], "usertype" => ["title" => "用户标识字段", "type" => "radio", "value" => "0", "options" => ["0" => "UserId", "1" => "OpenId"]]];

?>