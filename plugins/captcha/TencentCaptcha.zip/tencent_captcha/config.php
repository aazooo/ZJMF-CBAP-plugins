<?php
return ["module_name" => ["title" => "名称", "type" => "text", "value" => "腾讯图形验证", "tip" => "friendly name", "size" => 200], "secret_id" => ["title" => "SecretId", "type" => "text", "value" => "", "tip" => "", "size" => 200], "secret_key" => ["title" => "SecretKey", "type" => "text", "value" => "", "tip" => "", "size" => 200], "captcha_app_id" => ["title" => "CaptchaAppId", "type" => "text", "value" => "", "tip" => "", "size" => 200], "app_secret_key" => ["title" => "AppSecretKey", "type" => "text", "value" => "", "tip" => "", "size" => 200]];

?>