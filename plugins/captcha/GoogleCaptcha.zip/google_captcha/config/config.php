<?php
return ["endpoint" => "captcha.tencentcloudapi.com"];

?>