<?php
return ["module_name" => ["title" => "名称", "type" => "text", "value" => "谷歌图形验证", "tip" => "friendly name", "size" => 200], "site_key" => ["title" => "SiteKey", "type" => "text", "value" => "", "tip" => "", "size" => 200], "secret_key" => ["title" => "SecretKey", "type" => "text", "value" => "", "tip" => "", "size" => 200]];

?>